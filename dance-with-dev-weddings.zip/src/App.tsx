import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { EditorialIntro } from './components/EditorialIntro';
import { Experiences } from './components/Experiences';
import { FeaturedWork } from './components/FeaturedWork';
import { PersonalTouch } from './components/PersonalTouch';
import { HowItWorks } from './components/HowItWorks';
import { AboutSection } from './components/AboutSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { InstagramSection } from './components/InstagramSection';
import { EnquirySection } from './components/EnquirySection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  return (
    <div className="min-h-screen bg-[#F8F4EC] text-[#211D1C] flex flex-col font-sans selection:bg-[#651F35] selection:text-[#F8F4EC]">
      {/* Top Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Cinematic Hero */}
        <Hero />

        {/* 2. Emotional Storytelling Introduction */}
        <EditorialIntro />

        {/* 3. Choreography Experiences (6 Services) */}
        <Experiences />

        {/* 4. Featured Portfolio Films & Showcases */}
        <FeaturedWork />

        {/* 5. Personal Touch & Interactive Vibe Finder */}
        <PersonalTouch />

        {/* 6. How It Works (4-Step Process) */}
        <HowItWorks />

        {/* 7. About Dance With Dev & Founder Note */}
        <AboutSection />

        {/* 8. Testimonials & Real Couple Notes */}
        <TestimonialsSection />

        {/* 9. FAQs & Booking Guide */}
        <FaqSection />

        {/* 10. Instagram Magic Gallery (@dancewithdev.weddings) */}
        <InstagramSection />

        {/* 11. High-Converting Deep Burgundy Enquiry Section */}
        <EnquirySection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Action Button */}
      <FloatingWhatsApp />
    </div>
  );
}
