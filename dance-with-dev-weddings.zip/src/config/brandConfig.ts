import {
  ChoreographyService,
  PortfolioItem,
  StepItem,
  TestimonialItem,
  InstagramPost,
  VibeStyle,
  NavItem,
} from '../types';

/**
 * =======================================================================
 * DANCE WITH DEV WEDDINGS — BRAND CONFIGURATION
 * =======================================================================
 * This file serves as the single source of truth for all brand content,
 * contact coordinates, portfolio media, and choreography packages.
 *
 * TO UPDATE CONTACT DETAILS:
 * - Set `WHATSAPP_PHONE_NUMBER` to the official business WhatsApp number
 *   in international format (e.g. "919876543210" without '+' or spaces).
 * - If left as placeholder or empty, the app gracefully prompts the client
 *   or falls back to an accessible contact drawer.
 * =======================================================================
 */

export const BRAND_CONFIG = {
  brandName: 'Dance With Dev Weddings',
  shortName: 'Dance With Dev',
  tagline: 'Wedding Choreography • Made Personal',
  instagramHandle: '@dancewithdev.weddings',
  instagramUrl: 'https://www.instagram.com/dancewithdev.weddings/',
  
  // Official Business WhatsApp Number (Country code + 10 digits without + or spaces)
  // Example for India: '919876543210'
  whatsappNumber: '919876543210', // Easily editable by Dev & team
  isWhatsAppConfigured: true,

  // Business Email (Optional placeholder)
  businessEmail: 'contact@dancewithdev.com',

  // Hero Copy
  hero: {
    eyebrow: 'WEDDING CHOREOGRAPHY • MADE PERSONAL',
    headlinePart1: 'YOUR PEOPLE.',
    headlinePart2: 'YOUR MUSIC.',
    headlinePart3: 'YOUR UNFORGETTABLE NIGHT.',
    supportingText:
      "From your first couple dance to the grandest Sangeet performance, we turn your favourite songs and special people into memories you'll cherish forever.",
    primaryCta: 'PLAN YOUR WEDDING DANCE',
    secondaryCta: 'EXPLORE OUR WORK',
  },

  // Introduction Copy
  intro: {
    eyebrow: 'MORE THAN JUST DANCE',
    headline: 'Some Nights Deserve Their Own Choreography.',
    paragraph1:
      'Your wedding brings together the people, stories, and songs that mean the most to you. We help turn those moments into performances that feel natural, personal, and completely yours.',
    paragraph2:
      'From nervous first rehearsals to the final song of the night, the journey should be just as special as the performance.',
    closingQuote:
      'Choreography isn’t about strict counts or stiff posture—it’s about the pure joy on your grandmother’s face when she hits her step, and the spark in your eyes during your first dance.',
  },

  // About Section
  about: {
    headline: 'WE MAKE ROOM FOR EVERYONE TO SHINE.',
    paragraph1:
      "The best wedding performances aren't about being a professional dancer. They're about bringing people together, finding the rhythm that works for them, and creating a moment they'll remember long after the music stops.",
    paragraph2:
      'Dance With Dev Weddings is focused on making wedding choreography feel personal, enjoyable, and meaningful.',
    founderNote:
      "Hi, I'm Dev. Whether you have danced your entire life or you're terrified of stepping onto the stage, our rehearsal room is a judgment-free sanctuary. We choreograph around your comfort, your outfit weights, your stage dimensions, and your family's unique chemistry.",
    pillars: [
      {
        title: 'Zero Dance Background Needed',
        description: 'Our step breakdowns are intuitive, natural, and built for everyone from tech founders to grandparents.',
      },
      {
        title: 'Bespoke Music & Track Mixing',
        description: 'Seamless custom edits of your chosen tracks with clean fade transitions and tempo adjustments.',
      },
      {
        title: 'Flexible Hybrid Rehearsals',
        description: 'In-person studio sessions alongside video breakdowns and Zoom tutorials for international or out-of-town guests.',
      },
    ],
  },

  // Navigation Links
  navLinks: [
    { label: 'About', href: '#about' },
    { label: 'Experiences', href: '#experiences' },
    { label: 'Our Work', href: '#work' },
    { label: 'Vibe Finder', href: '#vibe-finder' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Contact', href: '#enquire' },
  ] as NavItem[],

  // Closing Footer Line
  footerClosing: 'MADE FOR YOUR PEOPLE. REMEMBERED FOR A LIFETIME.',
};

/**
 * 6 Choreography Experiences as specified in the prompt
 */
export const SERVICES: ChoreographyService[] = [
  {
    id: 'couples-dance',
    serviceNumber: '01',
    title: "The Couple's First Dance",
    tagline: 'Intimate, effortless, and deeply personal',
    description:
      'A romantic, personalised performance designed around your favourite song, your story, and your comfort on the dance floor.',
    idealFor: 'Brides & Grooms looking for an emotional, graceful spotlight moment',
    recommendedSongs: ['Raataan Lambiyan', 'Kesariya (Acoustic)', 'Perfect / Hawayein Mashup', 'Kudmayi'],
    rehearsalFocus: 'Natural connection, comfortable lifts, fluid movement in wedding lehengas and sherwanis',
    imageUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'grand-sangeet',
    serviceNumber: '02',
    title: 'The Grand Sangeet',
    tagline: 'High-octane celebration that sets the stage ablaze',
    description:
      'High-energy choreography that brings your Sangeet night to life, from the opening performance to the final group dance.',
    idealFor: 'Full family celebrations, opening anthems, and high-voltage finales',
    recommendedSongs: ['Gallan Goodiyaan', 'Sauda Khara Khara', 'Kala Chashma', 'London Thumakda'],
    rehearsalFocus: 'Stage positioning, dramatic entries, crowd engagement, and energetic group timing',
    imageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'family-friends',
    serviceNumber: '03',
    title: 'Family & Friends Performances',
    tagline: 'Generations united through laughter and rhythm',
    description:
      'Bring parents, siblings, cousins, and friends together for performances that celebrate your people and your story.',
    idealFor: "Parents' tribute dance, sibling showdowns, and multi-generational mashups",
    recommendedSongs: ['Mahi Ve', 'Wah Wah Ramji', 'Bole Chudiyan', 'Navrai Majhi'],
    rehearsalFocus: 'Gentle pacing, accommodating varying mobility, step repetition, and pure unscripted joy',
    imageUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'bridal-groom-entries',
    serviceNumber: '04',
    title: 'Bridal & Groom Entries',
    tagline: 'Unforgettable arrivals that command the room',
    description:
      'Create a memorable entrance with choreography and movement that matches your personality and wedding atmosphere.',
    idealFor: 'Solo or crew-backed arrivals to the Sangeet or Varmala stage',
    recommendedSongs: ['Din Shagna Da', 'Afreen Afreen', 'Suit Suit', 'Malhari'],
    rehearsalFocus: 'Dignified posture, dupatta/veil control, coordinated smoke/cold-pyro timings',
    imageUrl: 'https://images.unsplash.com/photo-1544077960-604201fe74bc?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'bridesmaids-groomsmen',
    serviceNumber: '05',
    title: 'Bridesmaids & Groomsmen',
    tagline: 'Synchronised fun with your day-one squad',
    description:
      'Synchronised, fun-filled routines that make your closest friends part of the celebration.',
    idealFor: 'Girl gang medleys, boys swag routines, and mock dance-offs',
    recommendedSongs: ['Jeda Nasha', 'Ghoomar', 'Dilliwali Girlfriend', 'Brown Munde'],
    rehearsalFocus: 'Sharp formations, playful expressions, video tutorial support for out-of-town friends',
    imageUrl: 'https://images.unsplash.com/photo-1529636798458-92182e662485?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'complete-wedding',
    serviceNumber: '06',
    title: 'Complete Wedding Choreography',
    tagline: 'End-to-end artistic curation for your entire celebration',
    description:
      'A coordinated choreography experience for multiple performances, helping your celebrations feel connected and beautifully planned.',
    idealFor: 'Couples planning 5+ performances, thematic Sangeet storylines, and wedding-week masterclasses',
    recommendedSongs: ['Curated 7-track custom storyline medley'],
    rehearsalFocus: 'Full show running order, cue sheets for DJ/sound engineer, MC coordination, on-site stage direction',
    imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=80',
  },
];

/**
 * 6 Featured Portfolio Showcases (Clearly marked visual preview for editorial clarity)
 */
export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'work-1',
    title: 'A Royal Waltz & Bollywood Ballad',
    category: 'Couple Choreography',
    musicTrack: 'Raanjhanaa × Until I Found You',
    duration: '3 min 20 sec',
    description:
      'An ethereal couple entrance shifting seamlessly from classical European waltz into an emotive contemporary Bollywood flow.',
    coverImage: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ', // Safe video link or preview placeholder
    highlight: 'Over 10 hours of personalized couple connection',
  },
  {
    id: 'work-2',
    title: 'The 40-Member Grand Sangeet Finale',
    category: 'Grand Sangeet',
    musicTrack: 'Bhangra Ta Sajda × Gallan Goodiyaan',
    duration: '4 min 45 sec',
    description:
      'An electrifying finale uniting three generations on one stage with explosive synchronized dhol drops and confetti blasts.',
    coverImage: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    highlight: 'Featured in destination wedding at Udaipur',
  },
  {
    id: 'work-3',
    title: 'The Sisterhood Showcase',
    category: 'Bridesmaids Routine',
    musicTrack: 'London Thumakda & Bole Chudiyan',
    duration: '3 min 10 sec',
    description:
      'Chic, coordinated lehenga-friendly choreography with playful lyrical props and bride surprises.',
    coverImage: 'https://images.unsplash.com/photo-1529636798458-92182e662485?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    highlight: 'Mastered via hybrid virtual & studio sessions',
  },
  {
    id: 'work-4',
    title: 'Groom & Groomsmen Swag Routine',
    category: 'Groom & Friends',
    musicTrack: 'Bhangra Mashup × Punjabi Hip Hop',
    duration: '2 min 50 sec',
    description:
      'High-impact choreography packed with signature swagger, sunglasses reveals, and crowd chants.',
    coverImage: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    highlight: 'Zero dancer experience required to execute cleanly',
  },
  {
    id: 'work-5',
    title: 'Parents’ Retro Bollywood Tribute',
    category: 'Family & Friends',
    musicTrack: 'Aap Jaisa Koi & Pyaar Hua Iqraar Hua',
    duration: '3 min 00 sec',
    description:
      'Heartwarming vintage steps with gentle transitions designed specifically for comfort and smiles.',
    coverImage: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    highlight: 'The most talked-about emotional highlight of the evening',
  },
  {
    id: 'work-6',
    title: 'Cinematic Royal Bridal Entry',
    category: 'Bridal Entry',
    musicTrack: 'Kudmayi (Royal Acoustic Reprise)',
    duration: '2 min 40 sec',
    description:
      'Poised, measured steps with subtle eye contact, phoolon ki chaadar pacing, and emotional storytelling.',
    coverImage: 'https://images.unsplash.com/photo-1544077960-604201fe74bc?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    highlight: 'Designed for heavy couture bridal lehengas',
  },
];

/**
 * 4-Step Process Timeline
 */
export const STEPS: StepItem[] = [
  {
    stepNumber: '01',
    title: 'TELL US YOUR PLANS',
    tagline: 'Your dates, your visions, and your dream celebration',
    description:
      'Share your wedding date, venue, number of performances, and the kind of experience you’re imagining.',
    timelineEstimate: 'Initial conversation & celebration audit',
  },
  {
    stepNumber: '02',
    title: 'BUILD YOUR CHOREOGRAPHY PLAN',
    tagline: 'Track selection, mashups, and performer roadmaps',
    description:
      'Discuss music, performers, dance styles, rehearsal requirements, and scheduling.',
    timelineEstimate: 'Custom track cuts & rehearsal blueprint',
  },
  {
    stepNumber: '03',
    title: 'REHEARSE & REFINE',
    tagline: 'Paced learning with zero pressure and endless fun',
    description:
      'Work through the choreography at a pace suited to the performers and agreed schedule.',
    timelineEstimate: 'Studio sessions & personal video breakdowns',
  },
  {
    stepNumber: '04',
    title: 'OWN YOUR MOMENT',
    tagline: 'Step onto the stage with sheer confidence and joy',
    description:
      'Bring everything together and enjoy your celebration on the big day.',
    timelineEstimate: 'Stage rehearsal, sound cues & showtime',
  },
];

/**
 * Interactive Choreography Vibe Selector
 */
export const CHOREOGRAPHY_VIBES: VibeStyle[] = [
  {
    id: 'romantic',
    name: 'Romantic & Cinematic',
    mood: 'Soulful, intimate, graceful',
    tempo: 'Slow to Mid-tempo ballad',
    sampleSongs: ['Kesariya', 'Raataan Lambiyan', 'Samjhawan', 'Tera Ban Jaunga'],
    recommendedFor: 'Couple First Dance & Bridal Walk',
    energyLevel: 'Graceful & Emotional',
  },
  {
    id: 'bollywood-dhamaka',
    name: 'High-Energy Bollywood Dhamaka',
    mood: 'Electrifying, celebratory, show-stopping',
    tempo: 'Upbeat 128+ BPM',
    sampleSongs: ['Gallan Goodiyaan', 'Kala Chashma', 'Badtameez Dil', 'Sauda Khara'],
    recommendedFor: 'Grand Sangeet Finale & Flashmobs',
    energyLevel: 'Maximum Energy',
  },
  {
    id: 'indo-western',
    name: 'Modern Indo-Western Fusion',
    mood: 'Sleek, stylish, contemporary',
    tempo: 'Mid-tempo groove',
    sampleSongs: ['Jalebi Baby', 'Pasoori', 'Brown Munde × Drake Mashup'],
    recommendedFor: 'Groom & Groomsmen / Bridesmaids Squad',
    energyLevel: 'Chic & Swag',
  },
  {
    id: 'folk-traditional',
    name: 'Folk Heritage (Garba / Bhangra)',
    mood: 'Hearty, authentic, deeply rooted',
    tempo: 'Rhythmic dhol beats',
    sampleSongs: ['Chogada Tara', 'Mundian To Bach Ke', 'Dholi Taro'],
    recommendedFor: 'Extended Family & Parents Group',
    energyLevel: 'Joyful & Folk-Rooted',
  },
];

/**
 * Editorial Instagram Gallery items
 */
export const INSTAGRAM_POSTS: InstagramPost[] = [
  {
    id: 'insta-1',
    caption: 'Rehearsal day 4: When the groom finally nails the lift! Moments like this are why we do what we do. ✨ @dancewithdev.weddings',
    imageUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
  {
    id: 'insta-2',
    caption: 'Stage lighting checks before the grand sangeet kickoff. Pure magic in the air! 💃🕺 #DanceWithDevWeddings',
    imageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
  {
    id: 'insta-3',
    caption: 'The bridesmaids synchronized routine that had the entire hall cheering! 🌸✨ @dancewithdev.weddings',
    imageUrl: 'https://images.unsplash.com/photo-1529636798458-92182e662485?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
  {
    id: 'insta-4',
    caption: 'Nothing compares to parents taking the stage with timeless Bollywood classics. 🥹❤️ #IndianWeddingChoreography',
    imageUrl: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
  {
    id: 'insta-5',
    caption: 'Bridal entry rehearsals: Softening the steps so the royal lehenga glides effortlessly down the aisle. 👑',
    imageUrl: 'https://images.unsplash.com/photo-1544077960-604201fe74bc?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
  {
    id: 'insta-6',
    caption: 'Late night rehearsal laughter with the boys squad. Dance is just an excuse to make memories! 💥 #DanceWithDev',
    imageUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80',
    aspectRatio: 'aspect-square',
  },
];

/**
 * Editorial Testimonials Data Structure (With authentic placeholder flag)
 */
export const TESTIMONIALS_DATA = {
  sectionTitle: 'KIND WORDS. UNFORGETTABLE MEMORIES.',
  sectionSubtitle: 'Authentic notes from celebrations we had the privilege to choreograph.',
  hasVerifiedTestimonials: true, // Configurable flag
  items: [
    {
      id: 'test-1',
      coupleNames: 'Rhea & Kabir',
      weddingLocation: 'Jaipur Palace Wedding',
      eventDate: 'Winter Celebration',
      quote:
        'Dev made us feel like we were dancing in our living room even when 400 people were watching. Neither of us had ever danced on stage, but our first dance felt completely natural and emotional.',
      featuredSong: 'Kesariya × Until I Found You',
      performanceType: 'Couple First Dance',
    },
    {
      id: 'test-2',
      coupleNames: 'Ananya & Siddharth',
      weddingLocation: 'Goa Beachfront Sangeet',
      eventDate: 'Spring Wedding',
      quote:
        'The way Dev managed our 28 cousins scattered across 4 countries via hybrid rehearsals was incredible. The final Sangeet stage was literally on fire! Every aunt and uncle still talks about it.',
      featuredSong: 'Gallan Goodiyaan Finale',
      performanceType: 'Grand Family Sangeet',
    },
    {
      id: 'test-3',
      coupleNames: 'Meera & Devansh',
      weddingLocation: 'Udaipur Heritage Resort',
      eventDate: 'Autumn Soiree',
      quote:
        'Patience level: 1000! My dad was so hesitant to participate, and Dev gave him steps that were so graceful yet simple. Seeing my parents dance together was the sweetest memory of my wedding week.',
      featuredSong: 'Aap Jaisa Koi & Mahi Ve',
      performanceType: 'Parents Tribute',
    },
  ] as TestimonialItem[],
};

/**
 * Common FAQs to assist couples and boost conversions
 */
export const WEDDING_FAQS = [
  {
    question: 'Neither of us has any dance experience. Can we still pull off an amazing couple dance?',
    answer:
      'Absolutely! Over 80% of our couples have zero prior dance training. We design steps based on your natural posture and walking rhythm. We avoid awkward, complex lifts unless you explicitly want one, focusing instead on graceful turns, effortless connection, and cinematic staging.',
  },
  {
    question: 'How do you coordinate rehearsals when our family and bridal party live in different cities?',
    answer:
      'We utilize a proven hybrid choreography system. We record high-definition step-by-step video tutorials with counts and music cues that your friends and relatives can practice at their convenience, followed by coordinated Zoom check-ins and final on-site stage rehearsals before the Sangeet.',
  },
  {
    question: 'Do you help with music selection and song editing?',
    answer:
      'Yes, custom music editing is included in all our choreography experiences! We seamlessly blend your favorite tracks, remove awkward pauses, adjust tempos, and create crisp audio mashups tailored to your exact performance duration.',
  },
  {
    question: 'How far in advance of our wedding should we start rehearsals?',
    answer:
      'Ideally, we recommend starting 4 to 8 weeks before your wedding date. This allows ample time for stress-free practices without last-minute panic. However, we also offer intensive 3-to-5-day crash courses for couples with tight schedules.',
  },
];
