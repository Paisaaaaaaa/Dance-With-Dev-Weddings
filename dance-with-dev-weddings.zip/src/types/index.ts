export interface NavItem {
  label: string;
  href: string;
}

export interface ChoreographyService {
  id: string;
  serviceNumber: string;
  title: string;
  tagline: string;
  description: string;
  idealFor: string;
  recommendedSongs: string[];
  rehearsalFocus: string;
  imageUrl: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  musicTrack: string;
  duration: string;
  description: string;
  coverImage: string;
  videoUrl?: string; // Optional real or demo video URL
  highlight: string;
}

export interface StepItem {
  stepNumber: string;
  title: string;
  tagline: string;
  description: string;
  timelineEstimate: string;
}

export interface TestimonialItem {
  id: string;
  coupleNames: string;
  weddingLocation: string;
  eventDate: string;
  quote: string;
  featuredSong: string;
  performanceType: string;
}

export interface InstagramPost {
  id: string;
  caption: string;
  likesPlaceholder?: string;
  imageUrl: string;
  aspectRatio: string;
}

export interface EnquiryFormData {
  fullName: string;
  whatsappNumber: string;
  email: string;
  weddingDate: string;
  weddingCityVenue: string;
  numberOfPerformances: string;
  choreographyTypes: string[];
  additionalDetails: string;
}

export interface VibeStyle {
  id: string;
  name: string;
  mood: string;
  tempo: string;
  sampleSongs: string[];
  recommendedFor: string;
  energyLevel: string;
}
