import React from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brandConfig';

export const Hero: React.FC = () => {
  return (
    <section
      id="home"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center overflow-hidden bg-[#211D1C] text-[#F8F4EC]"
    >
      {/* Background Photography with Warm Wedding Ambiance */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2000&q=85"
          alt="Cinematic Indian Sangeet wedding celebration dance floor"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center filter brightness-[0.72] contrast-[1.08] scale-100 transition-transform duration-1000 ease-out"
        />
        {/* Layered cinematic scrim for pristine WCAG AA contrast & warmth */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#211D1C] via-[#211D1C]/60 to-[#211D1C]/40" />
        <div className="absolute inset-0 bg-[#651F35]/30 mix-blend-multiply" />
      </div>

      {/* Decorative hairline gold frame accents */}
      <div className="absolute inset-6 sm:inset-10 lg:inset-14 border border-[#C6A56B]/20 pointer-events-none hidden sm:block z-10" />

      {/* Hero Content Box */}
      <div className="relative z-20 max-w-5xl mx-auto px-6 sm:px-8 pt-28 pb-20 text-center flex flex-col items-center">
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 mb-6 px-4 py-1.5 border border-[#C6A56B]/40 bg-[#211D1C]/60 backdrop-blur-sm rounded-full">
          <Sparkles className="w-3.5 h-3.5 text-[#C6A56B]" />
          <span className="text-[11px] sm:text-xs tracking-[0.25em] uppercase text-[#F8F4EC] font-sans font-medium">
            {BRAND_CONFIG.hero.eyebrow}
          </span>
        </div>

        {/* Main Headline with Editorial Stagger */}
        <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight text-[#F8F4EC] leading-[1.06] mb-6 max-w-4xl text-balance">
          <span className="block font-light">{BRAND_CONFIG.hero.headlinePart1}</span>
          <span className="block italic text-[#E8D3CC] font-normal">{BRAND_CONFIG.hero.headlinePart2}</span>
          <span className="block font-medium text-[#C6A56B]">{BRAND_CONFIG.hero.headlinePart3}</span>
        </h1>

        {/* Supporting Copy */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-[#F8F4EC]/90 font-sans font-light leading-relaxed mb-10 text-balance">
          {BRAND_CONFIG.hero.supportingText}
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 w-full max-w-md mx-auto">
          <a
            href="#enquire"
            className="w-full sm:w-auto px-8 py-3.5 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs sm:text-sm font-semibold tracking-[0.16em] uppercase transition-all duration-300 rounded-sm shadow-lg hover:shadow-[#C6A56B]/20 text-center whitespace-nowrap"
          >
            {BRAND_CONFIG.hero.primaryCta}
          </a>
          <a
            href="#work"
            className="w-full sm:w-auto px-8 py-3.5 border border-[#F8F4EC]/60 hover:border-[#C6A56B] hover:text-[#C6A56B] text-[#F8F4EC] text-xs sm:text-sm font-medium tracking-[0.16em] uppercase transition-all duration-300 rounded-sm text-center backdrop-blur-xs whitespace-nowrap"
          >
            {BRAND_CONFIG.hero.secondaryCta}
          </a>
        </div>

        {/* Key Trust Signals (Quiet Editorial Inline Text) */}
        <div className="mt-12 pt-6 border-t border-[#C6A56B]/20 flex flex-wrap items-center justify-center gap-6 text-xs text-[#E8D3CC]/80 font-sans">
          <span>Personalised Couple Stories</span>
          <span aria-hidden="true" className="text-[#C6A56B]">·</span>
          <span>High-Energy Sangeet Routines</span>
          <span aria-hidden="true" className="text-[#C6A56B]">·</span>
          <span>Zero Dance Experience Required</span>
        </div>
      </div>

      {/* Elegant Scroll Indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-20 flex flex-col items-center gap-2 text-[#C6A56B]/80 hover:text-[#C6A56B] transition-colors pointer-events-auto">
        <a href="#about" aria-label="Scroll to introduction" className="flex flex-col items-center gap-1 group">
          <span className="text-[10px] tracking-[0.3em] uppercase font-sans group-hover:tracking-[0.35em] transition-all">
            SCROLL TO EXPLORE
          </span>
          <ArrowDown className="w-4 h-4 animate-bounce text-[#C6A56B]" />
        </a>
      </div>
    </section>
  );
};
