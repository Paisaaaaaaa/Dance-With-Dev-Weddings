import React from 'react';
import { MessageCircle } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brandConfig';

export const FloatingWhatsApp: React.FC = () => {
  if (!BRAND_CONFIG.isWhatsAppConfigured) return null;

  const defaultMessage = encodeURIComponent(
    `Hello Dev! I would love to enquire about wedding and Sangeet choreography with Dance With Dev Weddings.`
  );
  const whatsappUrl = `https://wa.me/${BRAND_CONFIG.whatsappNumber}?text=${defaultMessage}`;

  return (
    <aside
      aria-label="Contact options"
      className="fixed bottom-6 right-6 z-40 animate-float-in pointer-events-auto"
    >
      <div className="relative group flex flex-col items-end">
        {/* Elegant Desktop Tooltip */}
        <div
          role="tooltip"
          className="hidden md:flex items-center gap-1.5 absolute bottom-full right-0 mb-3 px-3.5 py-1.5 bg-[#211D1C]/95 backdrop-blur-xs text-[#F8F4EC] border border-[#C6A56B]/40 rounded-xs shadow-2xl text-xs font-sans font-medium tracking-wide whitespace-nowrap opacity-0 translate-y-1 group-hover:opacity-100 group-hover:translate-y-0 pointer-events-none transition-all duration-200 z-50 after:content-[''] after:absolute after:top-full after:right-6 after:border-4 after:border-transparent after:border-t-[#211D1C]"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#C6A56B]" aria-hidden="true" />
          <span>Book your consultation</span>
        </div>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat directly on WhatsApp with Dance With Dev Weddings - Book your consultation"
          className="flex items-center gap-3 bg-[#25D366] text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-2xl hover:bg-[#20ba59] transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] focus-visible:ring-offset-2 hover:scale-105"
        >
          <MessageCircle className="w-6 h-6 fill-current text-white shrink-0" />
          <span className="hidden sm:inline font-sans text-xs font-semibold tracking-wider uppercase whitespace-nowrap">
            Chat on WhatsApp
          </span>
        </a>
      </div>
    </aside>
  );
};
