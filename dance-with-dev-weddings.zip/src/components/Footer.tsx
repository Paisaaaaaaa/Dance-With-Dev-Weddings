import React from 'react';
import { BRAND_CONFIG } from '../config/brandConfig';
import { Instagram, ArrowUp, MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#1A1615] text-[#F8F4EC] pt-20 pb-12 border-t border-[#C6A56B]/25">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-white/10">
          {/* Col 1: Wordmark & Statement (5 cols) */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div>
              <a href="#home" className="inline-block mb-4 group">
                <span className="font-serif text-2xl sm:text-3xl tracking-[0.16em] uppercase font-medium text-[#F8F4EC] group-hover:text-[#C6A56B] transition-colors">
                  DANCE WITH DEV
                </span>
                <span className="block text-[10px] tracking-[0.35em] uppercase text-[#C6A56B] font-sans font-semibold mt-0.5">
                  WEDDINGS
                </span>
              </a>
              <p className="text-sm text-[#F8F4EC]/70 font-sans font-light max-w-sm leading-relaxed mb-6">
                Bespoke Indian wedding and Sangeet choreography crafted around your people, your music, and your once-in-a-lifetime celebration.
              </p>
            </div>

            <div className="flex items-center gap-4">
              <a
                href={BRAND_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-[#C6A56B]/40 flex items-center justify-center text-[#C6A56B] hover:bg-[#C6A56B] hover:text-[#211D1C] transition-all"
                aria-label={`Follow on Instagram: ${BRAND_CONFIG.instagramHandle}`}
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={`https://wa.me/${BRAND_CONFIG.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-[#C6A56B]/40 flex items-center justify-center text-[#C6A56B] hover:bg-[#C6A56B] hover:text-[#211D1C] transition-all"
                aria-label="Direct WhatsApp Message"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <span className="text-xs text-[#E8D3CC]/70 font-sans">
                {BRAND_CONFIG.instagramHandle}
              </span>
            </div>
          </div>

          {/* Col 2: Navigation Links (3 cols) */}
          <div className="md:col-span-3">
            <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans block mb-6">
              NAVIGATION
            </span>
            <ul className="space-y-3 font-sans text-sm">
              {BRAND_CONFIG.navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#F8F4EC]/75 hover:text-[#C6A56B] transition-colors py-0.5 inline-block"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Enquiries & Booking Quick Link (4 cols) */}
          <div className="md:col-span-4 flex flex-col justify-between">
            <div>
              <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans block mb-6">
                PLAN YOUR WEDDING DANCE
              </span>
              <p className="text-xs sm:text-sm text-[#F8F4EC]/70 font-sans font-light leading-relaxed mb-6">
                Available for luxury destination weddings across India and worldwide. Early booking recommended for peak season dates.
              </p>
              <a
                href="#enquire"
                className="inline-block px-6 py-3 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm shadow-md"
              >
                LET'S PLAN YOUR SANGEET
              </a>
            </div>

            <div className="mt-8">
              <button
                type="button"
                onClick={scrollToTop}
                className="text-xs tracking-wider uppercase text-[#E8D3CC]/60 hover:text-[#C6A56B] transition-colors font-sans flex items-center gap-1.5 focus-visible:outline-none"
              >
                <span>Back to top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Closing Signature Line */}
        <div className="pt-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#E8D3CC]/60 font-sans">
          <p className="font-serif italic text-sm text-[#C6A56B] tracking-wide text-center sm:text-left">
            {BRAND_CONFIG.footerClosing}
          </p>

          <p className="text-center sm:text-right">
            © {currentYear} {BRAND_CONFIG.brandName}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
