import React from 'react';
import { BRAND_CONFIG } from '../config/brandConfig';
import { EditorialImage } from './EditorialImage';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section className="py-24 lg:py-32 bg-[#211D1C] text-[#F8F4EC] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Dev's Portrait / Rehearsal Visual (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative shadow-2xl rounded-xs overflow-hidden border border-[#C6A56B]/30">
              <EditorialImage
                src="/src/assets/images/regenerated_image_1793249325579.jpg"
                alt="Dev - Wedding Choreographer and Founder of Dance With Dev Weddings"
                fallbackCategory="Founder & Choreographer"
                fallbackTitle="Dev — Dance With Dev Weddings"
                aspectRatioClass="aspect-[4/5]"
                className="w-full"
                overlayGradient={true}
              />

              {/* Founder Tag Floating Badge */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#211D1C]/90 backdrop-blur-md border border-[#C6A56B]/30 rounded-xs">
                <span className="text-[10px] tracking-widest uppercase text-[#C6A56B] font-sans block mb-1">
                  DEV • LEAD CHOREOGRAPHER
                </span>
                <p className="font-serif italic text-sm text-[#F8F4EC]">
                  "We don't teach steps; we unlock confidence."
                </p>
                <div className="mt-2 text-[10px] text-[#E8D3CC]/60 font-sans tracking-wide">
                  Editable founder profile · Professional photo customizable
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Philosophy & Pillars (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-[1px] bg-[#C6A56B]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans">
                ABOUT DANCE WITH DEV
              </span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#F8F4EC] leading-[1.08] mb-6 font-normal">
              We Make Room for <br />
              <span className="italic text-[#C6A56B] font-medium">Everyone to Shine.</span>
            </h2>

            <div className="space-y-4 text-base sm:text-lg text-[#F8F4EC]/85 font-sans font-light leading-relaxed mb-8">
              <p>{BRAND_CONFIG.about.paragraph1}</p>
              <p>{BRAND_CONFIG.about.paragraph2}</p>
            </div>

            {/* Dev's Personal Note */}
            <div className="p-6 bg-[#2A2423] border-l-2 border-[#C6A56B] rounded-xs mb-8">
              <p className="font-serif italic text-base sm:text-lg text-[#E8D3CC] leading-relaxed">
                "{BRAND_CONFIG.about.founderNote}"
              </p>
              <span className="text-xs tracking-wider uppercase text-[#C6A56B] font-sans font-semibold mt-3 block">
                — Dev, Founder & Choreographer
              </span>
            </div>

            {/* 3 Core Pillars */}
            <div className="space-y-4 mb-10">
              {BRAND_CONFIG.about.pillars.map((pillar) => (
                <div key={pillar.title} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#C6A56B] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-[#F8F4EC] font-sans">
                      {pillar.title}
                    </h4>
                    <p className="text-xs text-[#F8F4EC]/70 font-sans font-light leading-relaxed mt-0.5">
                      {pillar.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href="#enquire"
                className="px-8 py-3.5 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm text-center shadow-lg inline-flex items-center justify-center gap-2"
              >
                <span>GET IN TOUCH WITH DEV</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
              <a
                href={BRAND_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 border border-[#C6A56B]/40 hover:border-[#C6A56B] text-[#C6A56B] text-xs font-medium tracking-widest uppercase rounded-sm text-center transition-colors"
              >
                FOLLOW ON INSTAGRAM
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
