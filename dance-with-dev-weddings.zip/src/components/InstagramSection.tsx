import React from 'react';
import { BRAND_CONFIG, INSTAGRAM_POSTS } from '../config/brandConfig';
import { EditorialImage } from './EditorialImage';
import { Instagram, ArrowUpRight } from 'lucide-react';

export const InstagramSection: React.FC = () => {
  return (
    <section className="py-24 lg:py-32 bg-[#211D1C] text-[#F8F4EC] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <Instagram className="w-4 h-4 text-[#C6A56B]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans">
              INSTAGRAM • {BRAND_CONFIG.instagramHandle}
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F8F4EC] font-normal leading-tight mb-4">
            A Little More <span className="italic text-[#E8D3CC]">Wedding Magic</span>
          </h2>
          <p className="text-sm sm:text-base text-[#F8F4EC]/75 font-sans font-light max-w-lg mx-auto mb-8">
            Behind the choreography, the rehearsals, the laughter, and the moments that make every celebration special.
          </p>
          <a
            href={BRAND_CONFIG.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-7 py-3 bg-gradient-to-r from-[#651F35] to-[#4A1425] border border-[#C6A56B]/40 hover:border-[#C6A56B] text-[#F8F4EC] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm shadow-lg hover:shadow-black/50"
          >
            <span>FOLLOW ALONG ON INSTAGRAM</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#C6A56B]" />
          </a>
        </div>

        {/* 6-Image Editorial Gallery */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {INSTAGRAM_POSTS.map((post) => (
            <a
              key={post.id}
              href={BRAND_CONFIG.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-xs bg-[#2A2423] border border-[#C6A56B]/20 aspect-square block shadow-md hover:border-[#C6A56B] transition-all"
            >
              <EditorialImage
                src={post.imageUrl}
                alt="Dance With Dev rehearsal behind the scenes Instagram post"
                fallbackCategory="Rehearsal Magic"
                fallbackTitle="@dancewithdev.weddings"
                aspectRatioClass="aspect-square"
                className="w-full h-full transition-transform duration-500 group-hover:scale-105"
              />

              {/* Instagram Hover Overlay */}
              <div className="absolute inset-0 bg-[#211D1C]/85 opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-between text-center">
                <div className="flex justify-end">
                  <Instagram className="w-4 h-4 text-[#C6A56B]" />
                </div>
                <p className="text-[11px] text-[#F8F4EC] font-sans line-clamp-4 leading-snug font-light">
                  {post.caption}
                </p>
                <span className="text-[9px] uppercase tracking-widest text-[#C6A56B] font-semibold">
                  View On Instagram →
                </span>
              </div>
            </a>
          ))}
        </div>

        {/* Bottom Small Handle Reference */}
        <div className="mt-8 text-center text-xs text-[#E8D3CC]/60 font-sans">
          Tag <span className="text-[#C6A56B] font-medium">{BRAND_CONFIG.instagramHandle}</span> in your Sangeet stories and rehearsal bloopers!
        </div>
      </div>
    </section>
  );
};
