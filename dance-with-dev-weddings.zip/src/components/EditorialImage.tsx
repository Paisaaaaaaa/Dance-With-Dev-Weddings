import React, { useState } from 'react';

interface EditorialImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  fallbackTitle?: string;
  fallbackCategory?: string;
  aspectRatioClass?: string;
  className?: string;
  overlayGradient?: boolean;
}

export const EditorialImage: React.FC<EditorialImageProps> = ({
  src,
  alt,
  fallbackTitle,
  fallbackCategory,
  aspectRatioClass = 'aspect-[16/10]',
  className = '',
  overlayGradient = false,
  ...props
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div
      className={`relative overflow-hidden bg-[#211D1C] ${aspectRatioClass} ${className}`}
    >
      {!hasError ? (
        <>
          {/* Subtle loading placeholder */}
          {!isLoaded && (
            <div className="absolute inset-0 bg-neutral-900 animate-pulse flex items-center justify-center">
              <span className="text-[#C6A56B] text-xs uppercase tracking-widest font-sans opacity-60">
                Loading visual...
              </span>
            </div>
          )}

          <img
            src={src}
            alt={alt}
            referrerPolicy="no-referrer"
            loading="lazy"
            onLoad={() => setIsLoaded(true)}
            onError={() => setHasError(true)}
            className={`w-full h-full object-cover transition-all duration-700 ${
              isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            }`}
            {...props}
          />
        </>
      ) : (
        /* Luxury editorial SVG / Canvas fallback if image fails */
        <div className="absolute inset-0 bg-gradient-to-br from-[#4A1425] via-[#211D1C] to-[#161211] p-6 flex flex-col justify-between items-center text-center border border-[#C6A56B]/20">
          <div className="w-full flex justify-between items-center opacity-40 text-[10px] tracking-widest text-[#C6A56B] uppercase font-sans">
            <span>DANCE WITH DEV</span>
            <span>WEDDINGS</span>
          </div>

          <div className="my-auto flex flex-col items-center">
            {/* Elegant Indian floral / choreography arch icon */}
            <svg
              className="w-12 h-12 text-[#C6A56B] mb-3 opacity-80"
              viewBox="0 0 48 48"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.2"
            >
              <circle cx="24" cy="24" r="20" strokeDasharray="3 3" />
              <path d="M24 8 C16 16, 16 32, 24 40 C32 32, 32 16, 24 8 Z" />
              <circle cx="24" cy="24" r="5" fill="#C6A56B" fillOpacity="0.4" />
              <path d="M12 24 H36" strokeDasharray="2 2" />
            </svg>

            {fallbackCategory && (
              <span className="text-xs uppercase tracking-widest text-[#C6A56B] font-medium mb-1">
                {fallbackCategory}
              </span>
            )}
            <h4 className="font-serif text-lg md:text-xl text-[#F8F4EC] max-w-xs font-normal leading-snug">
              {fallbackTitle || alt}
            </h4>
          </div>

          <div className="text-[11px] tracking-wider text-[#E8D3CC]/60 font-sans">
            Sangeet & Wedding Choreography
          </div>
        </div>
      )}

      {/* Optional cinematic film scrim overlay */}
      {overlayGradient && !hasError && (
        <div
          className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/85 via-black/30 to-transparent"
          aria-hidden="true"
        />
      )}
    </div>
  );
};
