import React, { useState } from 'react';
import { SERVICES } from '../config/brandConfig';
import { ChoreographyService } from '../types';
import { EditorialImage } from './EditorialImage';
import { ArrowUpRight, Check, X, Sparkles, Music } from 'lucide-react';

export const Experiences: React.FC = () => {
  const [selectedService, setSelectedService] = useState<ChoreographyService | null>(null);

  return (
    <section id="experiences" className="py-24 lg:py-32 bg-[#211D1C] text-[#F8F4EC] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-[#C6A56B]/20 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <span className="w-8 h-[1px] bg-[#C6A56B]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans">
                CHOREOGRAPHY EXPERIENCES
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#F8F4EC] font-normal leading-tight">
              A Dance for Every <span className="italic text-[#E8D3CC]">Wedding Moment</span>
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-[#F8F4EC]/70 max-w-md font-sans font-light">
            Whether you want an intimate first dance or an explosive 40-person family Sangeet, every performance is crafted around your comfort and story.
          </p>
        </div>

        {/* 6 Services Asymmetric Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="group relative bg-[#2A2423] border border-[#C6A56B]/20 rounded-xs overflow-hidden flex flex-col justify-between transition-all duration-500 hover:border-[#C6A56B]/70 hover:shadow-2xl hover:shadow-black/50"
            >
              {/* Image Preview with Hover Zoom */}
              <div className="relative overflow-hidden aspect-[16/11]">
                <EditorialImage
                  src={service.imageUrl}
                  alt={service.title}
                  fallbackCategory={service.title}
                  fallbackTitle={service.tagline}
                  aspectRatioClass="aspect-[16/11]"
                  className="w-full h-full transition-transform duration-700 group-hover:scale-105"
                  overlayGradient={true}
                />
                
                {/* Number Badge */}
                <span className="absolute top-4 left-4 z-10 text-[11px] font-sans font-semibold tracking-widest text-[#211D1C] bg-[#C6A56B] px-2.5 py-1 rounded-xs uppercase shadow">
                  {service.serviceNumber}
                </span>

                <span className="absolute top-4 right-4 z-10 text-[10px] uppercase tracking-wider text-[#F8F4EC]/80 bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-xs">
                  Bespoke Routine
                </span>
              </div>

              {/* Service Details */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif text-2xl text-[#F8F4EC] font-normal group-hover:text-[#C6A56B] transition-colors mb-2">
                    {service.title}
                  </h3>
                  <p className="text-xs uppercase tracking-wider text-[#C6A56B] font-sans font-medium mb-4">
                    {service.tagline}
                  </p>
                  <p className="text-sm text-[#F8F4EC]/80 font-sans leading-relaxed line-clamp-3 mb-6 font-light">
                    {service.description}
                  </p>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setSelectedService(service)}
                    className="text-xs tracking-wider uppercase text-[#C6A56B] hover:text-[#F8F4EC] transition-colors font-sans font-medium inline-flex items-center gap-1.5 focus-visible:outline-none focus-visible:underline"
                  >
                    <span>View Rehearsal Details</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href="#enquire"
                    className="text-xs text-[#F8F4EC]/60 hover:text-[#C6A56B] transition-colors font-sans"
                  >
                    Plan this dance →
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner with Quick CTA */}
        <div className="mt-16 p-8 bg-gradient-to-r from-[#651F35] via-[#4A1425] to-[#211D1C] border border-[#C6A56B]/30 rounded-xs flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs tracking-widest uppercase text-[#C6A56B] font-sans mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Full Celebration Packages</span>
            </div>
            <h4 className="font-serif text-xl sm:text-2xl text-[#F8F4EC]">
              Looking for a complete multiple-performance choreography setup?
            </h4>
            <p className="text-xs sm:text-sm text-[#F8F4EC]/80 font-sans font-light mt-1">
              We curate a seamless soundtrack and stage direction for your entire Sangeet night.
            </p>
          </div>
          <a
            href="#enquire"
            className="px-6 py-3 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase rounded-sm transition-all whitespace-nowrap shrink-0 shadow-md"
          >
            CUSTOMIZE YOUR PACKAGE
          </a>
        </div>
      </div>

      {/* Accessible Rehearsal Breakdown Modal */}
      {selectedService && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="service-modal-title"
        >
          <div className="bg-[#2A2423] border border-[#C6A56B]/40 max-w-2xl w-full rounded-xs shadow-2xl p-6 sm:p-8 relative text-[#F8F4EC] max-h-[90vh] overflow-y-auto">
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setSelectedService(null)}
              className="absolute top-5 right-5 p-2 text-[#F8F4EC]/70 hover:text-[#C6A56B] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] rounded"
              aria-label="Close modal"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Modal Content */}
            <span className="text-[11px] font-sans tracking-[0.2em] uppercase text-[#C6A56B] block mb-1">
              SERVICE {selectedService.serviceNumber} • EXPERIENCE GUIDE
            </span>
            <h3 id="service-modal-title" className="font-serif text-2xl sm:text-3xl text-[#F8F4EC] mb-2">
              {selectedService.title}
            </h3>
            <p className="text-xs tracking-wider uppercase text-[#E8D3CC] font-sans mb-6">
              {selectedService.tagline}
            </p>

            <div className="space-y-6 text-sm text-[#F8F4EC]/85 font-sans font-light">
              <div>
                <h4 className="text-xs uppercase tracking-wider text-[#C6A56B] font-semibold mb-2">
                  Experience Overview
                </h4>
                <p className="leading-relaxed bg-black/30 p-4 rounded-xs border border-white/5">
                  {selectedService.description}
                </p>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider text-[#C6A56B] font-semibold mb-2 flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C6A56B]" />
                  <span>Ideal For</span>
                </h4>
                <p className="leading-relaxed text-[#F8F4EC]/90 pl-5">
                  {selectedService.idealFor}
                </p>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider text-[#C6A56B] font-semibold mb-2 flex items-center gap-2">
                  <Music className="w-3.5 h-3.5 text-[#C6A56B]" />
                  <span>Sample Track Inspirations</span>
                </h4>
                <div className="flex flex-wrap gap-2 pl-5">
                  {selectedService.recommendedSongs.map((song) => (
                    <span
                      key={song}
                      className="text-xs px-3 py-1 bg-[#211D1C] border border-[#C6A56B]/30 rounded-xs text-[#E8D3CC]"
                    >
                      {song}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider text-[#C6A56B] font-semibold mb-2 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#C6A56B]" />
                  <span>Choreography & Rehearsal Focus</span>
                </h4>
                <p className="leading-relaxed text-[#F8F4EC]/90 pl-5">
                  {selectedService.rehearsalFocus}
                </p>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#C6A56B]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
              <span className="text-xs text-[#F8F4EC]/60 font-sans">
                Ready to bring this dance to life?
              </span>
              <a
                href="#enquire"
                onClick={() => setSelectedService(null)}
                className="w-full sm:w-auto px-6 py-2.5 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase rounded-sm text-center transition-colors"
              >
                BOOK THIS CHOREOGRAPHY
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
