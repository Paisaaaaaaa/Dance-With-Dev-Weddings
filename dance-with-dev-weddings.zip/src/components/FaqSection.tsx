import React, { useState } from 'react';
import { WEDDING_FAQS } from '../config/brandConfig';
import { Plus, Minus, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-24 lg:py-32 bg-[#F8F4EC] text-[#211D1C] relative border-t border-[#C6A56B]/20">
      <div className="max-w-4xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-[#651F35]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#651F35] font-semibold font-sans">
              REHEARSAL & BOOKING GUIDE
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#211D1C] font-normal leading-tight mb-4">
            Everything You Need <span className="italic text-[#651F35]">to Know</span>
          </h2>
          <p className="text-sm sm:text-base text-[#211D1C]/75 font-sans font-light">
            Clear answers to common questions about Sangeet rehearsals, musical tracks, and stage readiness.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {WEDDING_FAQS.map((faq, idx) => {
            const isOpen = openIndex === idx;

            return (
              <div
                key={faq.question}
                className="bg-[#FFFFFF] border border-[#C6A56B]/30 rounded-xs overflow-hidden shadow-xs transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full py-5 px-6 sm:px-8 text-left flex items-center justify-between gap-4 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#651F35]"
                  aria-expanded={isOpen}
                >
                  <span className="font-serif text-lg sm:text-xl text-[#211D1C] font-normal leading-snug">
                    {faq.question}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-[#F8F4EC] border border-[#C6A56B]/40 flex items-center justify-center text-[#651F35] shrink-0">
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 sm:px-8 pb-6 pt-1 text-sm text-[#211D1C]/80 font-sans font-light leading-relaxed border-t border-[#F8F4EC]">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Extra question note */}
        <div className="mt-12 text-center p-6 bg-[#E8D3CC]/30 border border-[#651F35]/20 rounded-xs">
          <p className="font-serif text-lg text-[#651F35] mb-2">
            Have a unique theme, song mashup idea, or stage setup in mind?
          </p>
          <a
            href="#enquire"
            className="text-xs uppercase tracking-wider text-[#651F35] font-semibold font-sans hover:underline"
          >
            Ask Dev directly on WhatsApp →
          </a>
        </div>
      </div>
    </section>
  );
};
