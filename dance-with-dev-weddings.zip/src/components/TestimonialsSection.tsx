import React, { useState } from 'react';
import { TESTIMONIALS_DATA } from '../config/brandConfig';
import { Quote, ChevronLeft, ChevronRight, Heart, Sparkles } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const items = TESTIMONIALS_DATA.items;

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % items.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
  };

  const activeItem = items[currentIndex];

  return (
    <section className="py-24 lg:py-32 bg-[#F8F4EC] text-[#211D1C] relative overflow-hidden border-t border-[#C6A56B]/20">
      <div className="max-w-5xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#651F35]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#651F35] font-semibold font-sans">
              TESTIMONIALS
            </span>
            <span className="w-6 h-[1px] bg-[#651F35]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#211D1C] font-normal leading-tight mb-3">
            Kind Words. <span className="italic text-[#651F35]">Unforgettable Memories.</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#211D1C]/70 font-sans font-light">
            {TESTIMONIALS_DATA.sectionSubtitle}
          </p>
        </div>

        {/* Testimonial Showcase Card */}
        <div className="relative bg-[#FFFFFF] border border-[#C6A56B]/30 rounded-xs p-8 sm:p-12 shadow-xl">
          <div className="absolute top-6 left-6 text-[#C6A56B]/30 pointer-events-none">
            <Quote className="w-16 h-16 -scale-x-100" />
          </div>

          <div className="relative z-10 flex flex-col items-center text-center max-w-3xl mx-auto">
            {/* Song & Performance Badge */}
            <div className="inline-flex items-center gap-2 text-xs font-sans text-[#651F35] tracking-wider uppercase mb-6 bg-[#E8D3CC]/30 px-3.5 py-1 rounded-full border border-[#651F35]/20">
              <Sparkles className="w-3.5 h-3.5 text-[#C6A56B]" />
              <span>{activeItem.performanceType}</span>
              <span aria-hidden="true" className="text-[#C6A56B]">·</span>
              <span>{activeItem.featuredSong}</span>
            </div>

            {/* Quote Body */}
            <p className="font-serif italic text-xl sm:text-2xl md:text-3xl text-[#211D1C] leading-relaxed mb-8">
              "{activeItem.quote}"
            </p>

            {/* Couple Attribution */}
            <div>
              <h3 className="font-serif text-2xl text-[#651F35] font-semibold">
                {activeItem.coupleNames}
              </h3>
              <p className="text-xs tracking-widest uppercase text-[#211D1C]/60 font-sans mt-1">
                {activeItem.weddingLocation} • {activeItem.eventDate}
              </p>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="mt-8 pt-6 border-t border-[#C6A56B]/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {items.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-1.5 transition-all rounded-full ${
                    currentIndex === idx ? 'w-8 bg-[#651F35]' : 'w-2 bg-[#C6A56B]/40'
                  }`}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={prevTestimonial}
                className="p-2 border border-[#C6A56B]/40 hover:bg-[#651F35] hover:text-[#F8F4EC] text-[#211D1C] transition-colors rounded-xs focus-visible:outline-none"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={nextTestimonial}
                className="p-2 border border-[#C6A56B]/40 hover:bg-[#651F35] hover:text-[#F8F4EC] text-[#211D1C] transition-colors rounded-xs focus-visible:outline-none"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Recent Couple Video Submission Invitation */}
        <div className="mt-12 text-center text-xs text-[#211D1C]/70 font-sans flex items-center justify-center gap-2">
          <Heart className="w-3.5 h-3.5 text-[#651F35]" />
          <span>Did Dev choreograph your Sangeet? Tag @dancewithdev.weddings to be featured!</span>
        </div>
      </div>
    </section>
  );
};
