import React from 'react';
import { BRAND_CONFIG } from '../config/brandConfig';
import { EditorialImage } from './EditorialImage';
import { Heart, Music, Sparkles } from 'lucide-react';

export const EditorialIntro: React.FC = () => {
  return (
    <section id="about" className="py-24 lg:py-32 bg-[#F8F4EC] text-[#211D1C] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Top Eyebrow */}
        <div className="flex items-center gap-3 mb-4">
          <span className="w-8 h-[1px] bg-[#C6A56B]" />
          <span className="text-xs uppercase tracking-[0.25em] text-[#651F35] font-semibold font-sans">
            {BRAND_CONFIG.intro.eyebrow}
          </span>
        </div>

        {/* Asymmetrical Editorial Composition */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Headline & Emotional Narrative (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#211D1C] leading-[1.12] mb-8 font-normal">
              Some Nights Deserve <br />
              <span className="italic text-[#651F35] font-medium">Their Own Choreography.</span>
            </h2>

            <div className="space-y-6 text-base sm:text-lg text-[#211D1C]/85 font-sans leading-relaxed font-light">
              <p>{BRAND_CONFIG.intro.paragraph1}</p>
              <p>{BRAND_CONFIG.intro.paragraph2}</p>
            </div>

            {/* Editorial Quote Box */}
            <div className="mt-10 p-6 sm:p-8 bg-[#E8D3CC]/30 border-l-2 border-[#651F35] rounded-xs">
              <p className="font-serif italic text-lg sm:text-xl text-[#651F35] leading-relaxed">
                "{BRAND_CONFIG.intro.closingQuote}"
              </p>
              <div className="mt-4 flex items-center gap-2 text-xs tracking-widest uppercase text-[#211D1C]/70 font-sans">
                <span>The Dance With Dev Philosophy</span>
              </div>
            </div>

            {/* 3 Core Experience Markers */}
            <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-[#C6A56B]/30">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-[#651F35] font-serif text-lg font-medium">
                  <Music className="w-4 h-4 text-[#C6A56B]" />
                  <span>Custom Medleys</span>
                </div>
                <p className="text-xs text-[#211D1C]/75 font-sans leading-relaxed">
                  Every song cut and mixed precisely to your comfort and mood.
                </p>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-[#651F35] font-serif text-lg font-medium">
                  <Heart className="w-4 h-4 text-[#C6A56B]" />
                  <span>Zero Judgement</span>
                </div>
                <p className="text-xs text-[#211D1C]/75 font-sans leading-relaxed">
                  Patient step-by-step guidance designed for non-dancers.
                </p>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2 text-[#651F35] font-serif text-lg font-medium">
                  <Sparkles className="w-4 h-4 text-[#C6A56B]" />
                  <span>Global Rehearsals</span>
                </div>
                <p className="text-xs text-[#211D1C]/75 font-sans leading-relaxed">
                  In-studio coaching paired with video breakdowns for distant family.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Layered Editorial Imagery (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Dominant Photograph */}
              <div className="relative shadow-2xl rounded-xs overflow-hidden border border-[#C6A56B]/30">
                <EditorialImage
                  src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1000&q=80"
                  alt="Couple first dance Indian wedding rehearsal celebration"
                  fallbackCategory="Couple Choreography"
                  fallbackTitle="The Intimate Couple Dance"
                  aspectRatioClass="aspect-[4/5]"
                  className="w-full"
                />
              </div>

              {/* Secondary Supporting Image (Overlapping Floating Offset) */}
              <div className="hidden sm:block absolute -bottom-10 -left-10 w-3/5 shadow-2xl rounded-xs overflow-hidden border-2 border-[#F8F4EC]">
                <EditorialImage
                  src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=700&q=80"
                  alt="Family and friends dancing at wedding"
                  fallbackCategory="Family Moments"
                  fallbackTitle="Laughter in Every Step"
                  aspectRatioClass="aspect-square"
                />
              </div>

              {/* Decorative Subtle Gold Badge */}
              <div className="absolute -top-4 -right-4 bg-[#651F35] text-[#F8F4EC] p-4 rounded-xs shadow-lg hidden sm:block">
                <div className="text-center font-serif text-sm tracking-wider uppercase text-[#C6A56B]">
                  Tailored To You
                </div>
                <div className="text-[10px] tracking-widest text-[#F8F4EC]/80 font-sans text-center mt-0.5">
                  Every Step, Every Song
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
