import React, { useState } from 'react';
import { PORTFOLIO_ITEMS } from '../config/brandConfig';
import { PortfolioItem } from '../types';
import { EditorialImage } from './EditorialImage';
import { VideoModal } from './VideoModal';
import { Play, Music2, Clock, Sparkles } from 'lucide-react';

export const FeaturedWork: React.FC = () => {
  const [activeVideoItem, setActiveVideoItem] = useState<PortfolioItem | null>(null);

  return (
    <section id="work" className="py-24 lg:py-32 bg-[#F8F4EC] text-[#211D1C] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#651F35]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#651F35] font-semibold font-sans">
              FEATURED WORK
            </span>
            <span className="w-6 h-[1px] bg-[#651F35]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#211D1C] font-normal leading-tight mb-4">
            The Moments That <span className="italic text-[#651F35]">Move Us</span>
          </h2>
          <p className="text-sm sm:text-base text-[#211D1C]/75 font-sans font-light max-w-xl mx-auto">
            Every celebration has its own rhythm. Here's where the magic comes together.
          </p>

          {/* Editorial Transparency Note */}
          <div className="mt-4 inline-flex items-center gap-1.5 text-[11px] text-[#651F35]/70 font-sans tracking-wide">
            <Sparkles className="w-3 h-3 text-[#C6A56B]" />
            <span>Curated Visual Showcase Preview • Custom video footage readily updated</span>
          </div>
        </div>

        {/* Editorial Film Collage Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          {PORTFOLIO_ITEMS.map((item, index) => {
            // Asymmetric layout logic for editorial magazine pacing
            const isLarge = index === 0 || index === 3;
            const colSpan = isLarge ? 'md:col-span-7' : 'md:col-span-5';

            return (
              <div
                key={item.id}
                className={`${colSpan} group relative bg-[#211D1C] text-[#F8F4EC] rounded-xs overflow-hidden shadow-xl border border-[#C6A56B]/20 flex flex-col justify-between transition-all duration-500 hover:shadow-2xl hover:border-[#C6A56B]/60`}
              >
                {/* Visual Thumbnail & Play Trigger */}
                <div className="relative overflow-hidden aspect-[16/10] sm:aspect-[16/9]">
                  <EditorialImage
                    src={item.coverImage}
                    alt={item.title}
                    fallbackCategory={item.category}
                    fallbackTitle={item.title}
                    aspectRatioClass="aspect-[16/10] sm:aspect-[16/9]"
                    className="w-full h-full transition-transform duration-700 group-hover:scale-105"
                    overlayGradient={true}
                  />

                  {/* Play Button Overlay */}
                  <button
                    type="button"
                    onClick={() => setActiveVideoItem(item)}
                    className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B]"
                    aria-label={`Play showcase video for ${item.title}`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#C6A56B]/90 text-[#211D1C] flex items-center justify-center transform group-hover:scale-110 transition-all duration-300 shadow-2xl backdrop-blur-xs">
                      <Play className="w-6 h-6 fill-current ml-1" />
                    </div>
                  </button>

                  {/* Category Pill Tag Replacement -> Clean Unboxed Header */}
                  <div className="absolute top-4 left-4 z-10 flex items-center gap-2 text-[10px] sm:text-xs font-sans tracking-widest uppercase text-[#F8F4EC] bg-black/60 px-3 py-1 rounded-xs backdrop-blur-xs">
                    <span>{item.category}</span>
                  </div>

                  <div className="absolute top-4 right-4 z-10 flex items-center gap-1 text-[11px] font-sans text-[#E8D3CC] bg-black/60 px-2.5 py-1 rounded-xs backdrop-blur-xs">
                    <Clock className="w-3 h-3 text-[#C6A56B]" />
                    <span>{item.duration}</span>
                  </div>
                </div>

                {/* Information Card */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between bg-gradient-to-b from-[#2A2423] to-[#211D1C]">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs text-[#C6A56B] font-sans mb-2">
                      <Music2 className="w-3.5 h-3.5" />
                      <span className="truncate">{item.musicTrack}</span>
                    </div>

                    <h3 className="font-serif text-xl sm:text-2xl text-[#F8F4EC] font-normal mb-3 group-hover:text-[#C6A56B] transition-colors leading-snug">
                      {item.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-[#F8F4EC]/75 font-sans leading-relaxed font-light mb-4">
                      {item.description}
                    </p>
                  </div>

                  {/* Footer Meta */}
                  <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                    <span className="text-[11px] text-[#E8D3CC]/70 font-sans italic truncate pr-2">
                      {item.highlight}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveVideoItem(item)}
                      className="text-xs text-[#C6A56B] hover:text-[#F8F4EC] uppercase tracking-wider font-semibold font-sans whitespace-nowrap focus-visible:outline-none"
                    >
                      Watch Clip →
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Portfolio CTA */}
        <div className="mt-16 text-center">
          <p className="font-serif italic text-lg sm:text-xl text-[#211D1C] mb-6">
            "Your favourite songs, choreographed so comfortably that you’ll forget the cameras are rolling."
          </p>
          <a
            href="#enquire"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#651F35] text-[#F8F4EC] hover:bg-[#4A1425] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm shadow-md"
          >
            <span>DISCUSS YOUR SANGEET VISION</span>
          </a>
        </div>
      </div>

      {/* Video Modal Trigger */}
      <VideoModal
        item={activeVideoItem}
        onClose={() => setActiveVideoItem(null)}
      />
    </section>
  );
};
