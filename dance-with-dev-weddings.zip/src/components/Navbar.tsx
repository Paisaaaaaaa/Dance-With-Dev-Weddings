import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brandConfig';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock body scroll when mobile menu is active
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  // Handle ESC key for accessible mobile menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMobileMenuOpen) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobileMenuOpen]);

  const closeMenu = () => setIsMobileMenuOpen(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#211D1C]/95 backdrop-blur-md border-b border-[#C6A56B]/25 py-3 shadow-lg shadow-black/20 text-[#F8F4EC]'
          : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent py-5 text-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <a
          href="#home"
          className="group flex flex-col whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] rounded"
          aria-label="Dance With Dev Weddings - Home"
        >
          <span className="font-serif text-xl sm:text-2xl tracking-[0.18em] uppercase font-medium text-[#F8F4EC] group-hover:text-[#C6A56B] transition-colors">
            DANCE WITH DEV
          </span>
          <span className="text-[9px] tracking-[0.35em] uppercase text-[#C6A56B] font-sans -mt-1 font-semibold">
            WEDDINGS
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav
          className="hidden md:flex items-center gap-7 lg:gap-8 text-xs lg:text-sm font-medium tracking-wider uppercase font-sans"
          aria-label="Main Navigation"
        >
          {BRAND_CONFIG.navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-[#F8F4EC]/85 hover:text-[#C6A56B] transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#C6A56B] hover:after:w-full after:transition-all after:duration-300 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] rounded"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="hidden md:flex items-center gap-4 shrink-0">
          <a
            href="#enquire"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase transition-all duration-300 rounded-sm shadow-md hover:shadow-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white whitespace-nowrap shrink-0"
          >
            <span>LET'S PLAN YOUR SANGEET</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Mobile Menu Toggle Button */}
        <div className="flex md:hidden items-center gap-3">
          <a
            href="#enquire"
            className="px-3 py-1.5 bg-[#C6A56B] text-[#211D1C] text-[11px] font-bold tracking-wider uppercase rounded-sm whitespace-nowrap"
          >
            ENQUIRE
          </a>
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-[#F8F4EC] hover:text-[#C6A56B] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] rounded"
            aria-expanded={isMobileMenuOpen}
            aria-label={isMobileMenuOpen ? 'Close Menu' : 'Open Menu'}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Accessible Fullscreen Mobile Drawer */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 top-[60px] bg-[#211D1C] z-40 md:hidden flex flex-col justify-between p-6 sm:p-8 animate-fadeIn border-t border-[#C6A56B]/20 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile Navigation Menu"
        >
          <div className="flex flex-col space-y-5 pt-4">
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#C6A56B] font-sans">
              MENU
            </span>
            {BRAND_CONFIG.navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={closeMenu}
                className="font-serif text-2xl text-[#F8F4EC] hover:text-[#C6A56B] tracking-wide transition-colors py-1 border-b border-[#F8F4EC]/10"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-8 pb-10 flex flex-col gap-4">
            <a
              href="#enquire"
              onClick={closeMenu}
              className="w-full text-center py-3.5 bg-[#C6A56B] text-[#211D1C] font-semibold text-xs tracking-widest uppercase rounded-sm shadow-md"
            >
              LET'S PLAN YOUR SANGEET
            </a>
            <a
              href={BRAND_CONFIG.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full text-center py-3 border border-[#C6A56B]/40 text-[#C6A56B] text-xs tracking-widest uppercase hover:bg-[#C6A56B]/10 rounded-sm"
            >
              FOLLOW {BRAND_CONFIG.instagramHandle}
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
