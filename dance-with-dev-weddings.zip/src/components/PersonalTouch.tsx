import React, { useState } from 'react';
import { CHOREOGRAPHY_VIBES } from '../config/brandConfig';
import { EditorialImage } from './EditorialImage';
import { Sparkles, Music, Flame } from 'lucide-react';

export const PersonalTouch: React.FC = () => {
  const [activeVibeId, setActiveVibeId] = useState(CHOREOGRAPHY_VIBES[0].id);
  const currentVibe = CHOREOGRAPHY_VIBES.find((v) => v.id === activeVibeId) || CHOREOGRAPHY_VIBES[0];

  return (
    <section id="vibe-finder" className="py-24 lg:py-32 bg-[#211D1C] text-[#F8F4EC] relative overflow-hidden">
      {/* Decorative background watermark-free subtle lighting */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#651F35]/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        {/* Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Immersive Editorial Wedding Visual (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative shadow-2xl rounded-xs overflow-hidden border border-[#C6A56B]/30">
              <EditorialImage
                src="/src/assets/images/regenerated_image_1793249327431.jpg"
                alt="Indian wedding bride and groom elegant couple choreography"
                fallbackCategory="Personal Touch"
                fallbackTitle="Your Story, Your Song, Your Moment"
                aspectRatioClass="aspect-[3/4]"
                className="w-full"
                overlayGradient={true}
              />
              {/* Subtle Overlay Label */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#211D1C]/80 backdrop-blur-md border border-[#C6A56B]/30 rounded-xs">
                <span className="text-[10px] tracking-widest uppercase text-[#C6A56B] font-sans block mb-1">
                  CUSTOM MUSIC & PACING
                </span>
                <p className="font-serif italic text-base text-[#F8F4EC]">
                  "Crafted for how you actually move, not how a textbook tells you to."
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Oversized Editorial Typography & Interactive Vibe Finder (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="flex items-center gap-3 mb-4">
              <span className="w-8 h-[1px] bg-[#C6A56B]" />
              <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans">
                THE PERSONAL TOUCH
              </span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#F8F4EC] leading-[1.08] mb-6 font-normal">
              Your Story. Your Song. <br />
              <span className="italic text-[#C6A56B] font-medium">Your Moment.</span>
            </h2>

            <div className="space-y-4 text-base sm:text-lg text-[#F8F4EC]/85 font-sans font-light leading-relaxed mb-8">
              <p>
                No two couples are the same, and your choreography shouldn’t be either.
              </p>
              <p>
                We shape every performance around your music, your personalities, your people, and the kind of celebration you want to create.
              </p>
            </div>

            {/* Interactive Vibe Explorer */}
            <div className="bg-[#2A2423] border border-[#C6A56B]/30 rounded-xs p-6 sm:p-7 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs tracking-wider uppercase text-[#C6A56B] font-semibold font-sans flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#C6A56B]" />
                  <span>Explore Your Celebration Vibe</span>
                </span>
                <span className="text-[11px] text-[#E8D3CC]/60 font-sans hidden sm:inline">
                  Click a style to preview
                </span>
              </div>

              {/* Segmented Filter Control */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
                {CHOREOGRAPHY_VIBES.map((vibe) => (
                  <button
                    key={vibe.id}
                    type="button"
                    onClick={() => setActiveVibeId(vibe.id)}
                    className={`px-3 py-2 text-xs font-sans text-center transition-all rounded-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C6A56B] ${
                      activeVibeId === vibe.id
                        ? 'bg-[#C6A56B] text-[#211D1C] font-semibold shadow-sm'
                        : 'bg-[#211D1C] text-[#F8F4EC]/80 hover:text-white hover:bg-white/5 border border-white/5'
                    }`}
                  >
                    {vibe.name.split(' ')[0]}
                  </button>
                ))}
              </div>

              {/* Active Vibe Card */}
              <div className="border-t border-[#C6A56B]/20 pt-4 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="font-serif text-xl text-[#F8F4EC]">
                    {currentVibe.name}
                  </h4>
                  <span className="text-xs text-[#C6A56B] font-sans flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5" />
                    <span>{currentVibe.energyLevel}</span>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-[#F8F4EC]/80 font-sans">
                  <div>
                    <span className="text-[#E8D3CC]/60 uppercase tracking-wider block text-[10px]">
                      Ideal For
                    </span>
                    <span className="font-medium text-[#F8F4EC]">
                      {currentVibe.recommendedFor}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#E8D3CC]/60 uppercase tracking-wider block text-[10px]">
                      Musical Tempo
                    </span>
                    <span className="font-medium text-[#F8F4EC]">{currentVibe.tempo}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[#E8D3CC]/60 uppercase tracking-wider block text-[10px] mb-1.5 flex items-center gap-1">
                    <Music className="w-3 h-3 text-[#C6A56B]" />
                    <span>Popular Tracks in this Style</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {currentVibe.sampleSongs.map((song) => (
                      <span
                        key={song}
                        className="text-[11px] px-2.5 py-1 bg-[#211D1C] border border-[#C6A56B]/20 rounded-xs text-[#E8D3CC]"
                      >
                        {song}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href="#enquire"
                className="px-8 py-3.5 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm text-center shadow-lg whitespace-nowrap"
              >
                DISCUSS YOUR VISION WITH US
              </a>
              <span className="text-xs text-[#F8F4EC]/60 font-sans text-center sm:text-left">
                Every routine customized to your preferred playlist
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
