import React, { useState } from 'react';
import { BRAND_CONFIG, SERVICES } from '../config/brandConfig';
import { EnquiryFormData } from '../types';
import { MessageSquare, Send, CheckCircle2, Shield, Calendar, MapPin, Sparkles, User, Phone, Mail } from 'lucide-react';

export const EnquirySection: React.FC = () => {
  const [formData, setFormData] = useState<EnquiryFormData>({
    fullName: '',
    whatsappNumber: '',
    email: '',
    weddingDate: '',
    weddingCityVenue: '',
    numberOfPerformances: '2 - 3 Performances',
    choreographyTypes: [SERVICES[0].title],
    additionalDetails: '',
  });

  const [errors, setErrors] = useState<{ fullName?: string; whatsappNumber?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [generatedMessage, setGeneratedMessage] = useState('');

  const toggleChoreographyType = (title: string) => {
    setFormData((prev) => {
      const exists = prev.choreographyTypes.includes(title);
      if (exists) {
        // keep at least one selected
        if (prev.choreographyTypes.length === 1) return prev;
        return {
          ...prev,
          choreographyTypes: prev.choreographyTypes.filter((t) => t !== title),
        };
      } else {
        return {
          ...prev,
          choreographyTypes: [...prev.choreographyTypes, title],
        };
      }
    });
  };

  const validate = () => {
    const newErrors: { fullName?: string; whatsappNumber?: string } = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Please enter your full name.';
    } else if (formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Name must be at least 2 characters.';
    }

    // WhatsApp number validation (strip non-digits, ensure length >= 10)
    const cleanedPhone = formData.whatsappNumber.replace(/[^0-9]/g, '');
    if (!formData.whatsappNumber.trim()) {
      newErrors.whatsappNumber = 'Please enter your WhatsApp contact number.';
    } else if (cleanedPhone.length < 9 || cleanedPhone.length > 15) {
      newErrors.whatsappNumber = 'Please enter a valid phone number with country code.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const buildWhatsAppMessage = () => {
    const choreoList = formData.choreographyTypes.join(', ');
    const lines = [
      `*Wedding Choreography Enquiry — Dance With Dev Weddings*`,
      ``,
      `*Name:* ${formData.fullName}`,
      `*WhatsApp:* ${formData.whatsappNumber}`,
      formData.email ? `*Email:* ${formData.email}` : '',
      formData.weddingDate ? `*Wedding Date:* ${formData.weddingDate}` : '',
      formData.weddingCityVenue ? `*City/Venue:* ${formData.weddingCityVenue}` : '',
      `*Est. Performances:* ${formData.numberOfPerformances}`,
      `*Choreography Interests:* ${choreoList}`,
      formData.additionalDetails ? `*Vision / Notes:* ${formData.additionalDetails}` : '',
      ``,
      `_Sent from dancewithdev.com wedding inquiry form_`,
    ].filter(Boolean);

    return lines.join('\n');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const message = buildWhatsAppMessage();
    setGeneratedMessage(message);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);

      // Construct and trigger WhatsApp URL
      const encodedMsg = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/${BRAND_CONFIG.whatsappNumber}?text=${encodedMsg}`;
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    }, 600);
  };

  const handleDirectWhatsAppChat = () => {
    const defaultMsg = encodeURIComponent(
      `Hi Dev! I came across @dancewithdev.weddings and would love to discuss choreography for our upcoming wedding celebration.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber}?text=${defaultMsg}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="enquire" className="py-24 lg:py-32 bg-[#651F35] text-[#F8F4EC] relative overflow-hidden">
      {/* Background subtle imagery texture with deep burgundy scrim */}
      <div className="absolute inset-0 pointer-events-none opacity-15 mix-blend-overlay">
        <img
          src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2000&q=80"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      <div className="max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#C6A56B] font-semibold font-sans">
              START YOUR CELEBRATION
            </span>
            <span className="w-6 h-[1px] bg-[#C6A56B]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#F8F4EC] font-normal leading-tight mb-4">
            Let's Make Your Wedding <br />
            <span className="italic text-[#E8D3CC]">Unforgettable.</span>
          </h2>
          <p className="text-sm sm:text-base text-[#F8F4EC]/85 font-sans font-light leading-relaxed">
            Tell us a little about your celebration, and let's explore how we can bring your wedding dance vision to life.
          </p>
        </div>

        {/* Enquiry Form Container */}
        <div className="bg-[#211D1C]/90 backdrop-blur-md border border-[#C6A56B]/40 rounded-xs p-6 sm:p-10 lg:p-12 shadow-2xl">
          {isSubmitted ? (
            <div className="text-center py-10 space-y-6 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-[#C6A56B] text-[#211D1C] flex items-center justify-center mx-auto shadow-lg">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-serif text-3xl text-[#F8F4EC]">
                Thank You, {formData.fullName}!
              </h3>
              <p className="text-sm text-[#F8F4EC]/85 font-sans max-w-md mx-auto leading-relaxed">
                Your enquiry details have been formatted and WhatsApp should have opened in a new tab. If WhatsApp did not open automatically, tap the button below:
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                <a
                  href={`https://wa.me/${BRAND_CONFIG.whatsappNumber}?text=${encodeURIComponent(generatedMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3.5 bg-[#C6A56B] text-[#211D1C] font-semibold text-xs tracking-widest uppercase rounded-sm inline-flex items-center gap-2 shadow-lg"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>OPEN IN WHATSAPP</span>
                </a>
                <button
                  type="button"
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-3 border border-white/20 text-xs tracking-wider uppercase text-[#F8F4EC]/80 hover:text-white rounded-sm"
                >
                  Edit Enquiry
                </button>
              </div>

              {/* Message preview box */}
              <div className="mt-6 p-4 bg-black/40 border border-white/10 rounded-xs text-left max-w-md mx-auto">
                <span className="text-[10px] tracking-wider uppercase text-[#C6A56B] font-sans block mb-2">
                  Generated Message Summary
                </span>
                <pre className="text-xs text-[#E8D3CC]/80 whitespace-pre-wrap font-sans">
                  {generatedMessage}
                </pre>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="space-y-6">
              {/* Row 1: Full Name & WhatsApp Number */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="fullName" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>Full Name <span className="text-[#E8D3CC]">*</span></span>
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => {
                      setFormData({ ...formData, fullName: e.target.value });
                      if (errors.fullName) setErrors({ ...errors, fullName: undefined });
                    }}
                    placeholder="e.g. Ananya Sharma"
                    className={`w-full px-4 py-3 bg-[#1A1615] border ${
                      errors.fullName ? 'border-red-400' : 'border-[#C6A56B]/30'
                    } rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors`}
                  />
                  {errors.fullName && (
                    <p className="mt-1.5 text-xs text-red-300 font-sans">{errors.fullName}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="whatsappNumber" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5" />
                    <span>WhatsApp Number <span className="text-[#E8D3CC]">*</span></span>
                  </label>
                  <input
                    id="whatsappNumber"
                    type="tel"
                    required
                    value={formData.whatsappNumber}
                    onChange={(e) => {
                      setFormData({ ...formData, whatsappNumber: e.target.value });
                      if (errors.whatsappNumber) setErrors({ ...errors, whatsappNumber: undefined });
                    }}
                    placeholder="e.g. +91 98765 43210"
                    className={`w-full px-4 py-3 bg-[#1A1615] border ${
                      errors.whatsappNumber ? 'border-red-400' : 'border-[#C6A56B]/30'
                    } rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors`}
                  />
                  {errors.whatsappNumber && (
                    <p className="mt-1.5 text-xs text-red-300 font-sans">{errors.whatsappNumber}</p>
                  )}
                </div>
              </div>

              {/* Row 2: Email & Wedding Date */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="email" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" />
                    <span>Email Address (Optional)</span>
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. ananya@wedding.com"
                    className="w-full px-4 py-3 bg-[#1A1615] border border-[#C6A56B]/30 rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors"
                  />
                </div>

                <div>
                  <label htmlFor="weddingDate" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Wedding / Sangeet Date (Optional)</span>
                  </label>
                  <input
                    id="weddingDate"
                    type="text"
                    value={formData.weddingDate}
                    onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                    placeholder="e.g. December 2026 or Spring 2027"
                    className="w-full px-4 py-3 bg-[#1A1615] border border-[#C6A56B]/30 rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors"
                  />
                </div>
              </div>

              {/* Row 3: City/Venue & Number of Performances */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="weddingCityVenue" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Wedding City or Venue (Optional)</span>
                  </label>
                  <input
                    id="weddingCityVenue"
                    type="text"
                    value={formData.weddingCityVenue}
                    onChange={(e) => setFormData({ ...formData, weddingCityVenue: e.target.value })}
                    placeholder="e.g. Mumbai, Udaipur, Goa, Delhi, or Destination"
                    className="w-full px-4 py-3 bg-[#1A1615] border border-[#C6A56B]/30 rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors"
                  />
                </div>

                <div>
                  <label htmlFor="numberOfPerformances" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Number of Performances (Optional)</span>
                  </label>
                  <select
                    id="numberOfPerformances"
                    value={formData.numberOfPerformances}
                    onChange={(e) => setFormData({ ...formData, numberOfPerformances: e.target.value })}
                    className="w-full px-4 py-3 bg-[#1A1615] border border-[#C6A56B]/30 rounded-xs text-[#F8F4EC] text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors"
                  >
                    <option value="1 Performance (Couple First Dance)">1 Performance (Couple First Dance)</option>
                    <option value="2 - 3 Performances">2 - 3 Performances</option>
                    <option value="4 - 6 Performances (Full Sangeet)">4 - 6 Performances (Full Sangeet)</option>
                    <option value="7+ Performances (Grand Wedding Package)">7+ Performances (Grand Wedding Package)</option>
                  </select>
                </div>
              </div>

              {/* Choreography Types Selectable Options */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2">
                  Choreography Experiences You Need (Select All That Apply):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {SERVICES.map((service) => {
                    const isSelected = formData.choreographyTypes.includes(service.title);
                    return (
                      <button
                        key={service.id}
                        type="button"
                        onClick={() => toggleChoreographyType(service.title)}
                        className={`p-3 text-left border rounded-xs transition-all text-xs font-sans flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#651F35] border-[#C6A56B] text-[#F8F4EC] font-medium'
                            : 'bg-[#1A1615] border-white/10 text-[#F8F4EC]/70 hover:border-[#C6A56B]/50'
                        }`}
                      >
                        <span className="pr-2">{service.title}</span>
                        <div
                          className={`w-4 h-4 rounded-xs border flex items-center justify-center shrink-0 ${
                            isSelected
                              ? 'bg-[#C6A56B] border-[#C6A56B] text-[#211D1C]'
                              : 'border-white/20'
                          }`}
                        >
                          {isSelected && <span className="text-[10px] font-bold">✓</span>}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Additional Details */}
              <div>
                <label htmlFor="additionalDetails" className="block text-xs uppercase tracking-wider text-[#C6A56B] font-semibold font-sans mb-2">
                  Additional Details or Preferred Songs (Optional)
                </label>
                <textarea
                  id="additionalDetails"
                  rows={3}
                  value={formData.additionalDetails}
                  onChange={(e) => setFormData({ ...formData, additionalDetails: e.target.value })}
                  placeholder="Tell us about your favourite tracks, dance comfort levels, surprise ideas, or scheduling questions..."
                  className="w-full px-4 py-3 bg-[#1A1615] border border-[#C6A56B]/30 rounded-xs text-[#F8F4EC] placeholder-white/30 text-sm font-sans focus:outline-none focus:border-[#C6A56B] transition-colors"
                />
              </div>

              {/* Privacy Notice */}
              <div className="flex items-start gap-2 text-[11px] text-[#E8D3CC]/70 font-sans leading-relaxed pt-2">
                <Shield className="w-4 h-4 text-[#C6A56B] shrink-0 mt-0.5" />
                <p>
                  Privacy Notice: Submitting this form prepares your details and opens your prefilled enquiry in WhatsApp for immediate response. Your data is not stored on external advertising servers.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:flex-1 py-4 bg-[#C6A56B] hover:bg-[#d8bb83] text-[#211D1C] font-semibold text-xs tracking-[0.16em] uppercase rounded-sm transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
                >
                  {isSubmitting ? (
                    <span>PREPARING YOUR ENQUIRY...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>LET'S PLAN YOUR WEDDING</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleDirectWhatsAppChat}
                  className="w-full sm:w-auto px-6 py-4 border border-[#C6A56B]/50 hover:bg-[#C6A56B]/10 text-[#C6A56B] font-medium text-xs tracking-wider uppercase rounded-sm transition-colors flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>CHAT WITH US ON WHATSAPP</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
