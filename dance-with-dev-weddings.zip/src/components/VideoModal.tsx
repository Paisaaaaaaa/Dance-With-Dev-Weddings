import React, { useEffect } from 'react';
import { X, Play, Volume2, Sparkles } from 'lucide-react';
import { PortfolioItem } from '../types';

interface VideoModalProps {
  item: PortfolioItem | null;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ item, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-labelledby="video-modal-title"
    >
      <div className="relative w-full max-w-4xl bg-[#211D1C] border border-[#C6A56B]/40 rounded-xs overflow-hidden shadow-2xl text-[#F8F4EC]">
        {/* Top Bar with Title & Close */}
        <div className="px-6 py-4 border-b border-[#C6A56B]/20 flex items-center justify-between bg-[#1A1615]">
          <div>
            <span className="text-[10px] tracking-widest uppercase text-[#C6A56B] font-sans block">
              {item.category} • {item.duration}
            </span>
            <h3 id="video-modal-title" className="font-serif text-lg sm:text-xl text-[#F8F4EC]">
              {item.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-[#F8F4EC]/70 hover:text-[#C6A56B] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6A56B] rounded"
            aria-label="Close video player"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Cinematic Video Player Stage */}
        <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
          {/* Authentic Video / Cinematic Preview Canvas */}
          <img
            src={item.coverImage}
            alt={item.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover filter brightness-[0.65]"
          />

          {/* Interactive Player Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 flex flex-col justify-between p-6">
            <div className="flex items-center justify-between text-xs text-[#E8D3CC]/80 font-sans">
              <span className="flex items-center gap-1.5 bg-black/50 px-3 py-1 rounded-full border border-[#C6A56B]/30">
                <Volume2 className="w-3.5 h-3.5 text-[#C6A56B]" />
                <span>Track: {item.musicTrack}</span>
              </span>
              <span className="bg-[#651F35]/80 text-[#F8F4EC] px-3 py-1 rounded-full text-[10px] tracking-widest uppercase">
                Visual Showcase
              </span>
            </div>

            {/* Center Play Indicator */}
            <div className="flex flex-col items-center justify-center my-auto text-center px-4">
              <div className="w-16 h-16 rounded-full bg-[#C6A56B] text-[#211D1C] flex items-center justify-center shadow-2xl mb-4 transform hover:scale-110 transition-transform cursor-pointer">
                <Play className="w-7 h-7 fill-current ml-1" />
              </div>
              <p className="font-serif text-xl sm:text-2xl text-[#F8F4EC] max-w-lg mb-2">
                "{item.title}"
              </p>
              <p className="text-xs sm:text-sm text-[#F8F4EC]/80 font-sans max-w-md font-light">
                {item.description}
              </p>
            </div>

            <div className="flex items-center justify-between text-xs text-[#F8F4EC]/60 font-sans border-t border-white/10 pt-3">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#C6A56B]" />
                <span>{item.highlight}</span>
              </span>
              <span>Available for 2026/2027 Wedding Season</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 bg-[#1A1615] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#E8D3CC]/80 font-sans text-center sm:text-left">
            Want choreography tailored around this musical style?
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-[#F8F4EC]/20 text-[#F8F4EC]/80 hover:text-white text-xs uppercase tracking-wider rounded-sm transition-colors"
            >
              Close
            </button>
            <a
              href="#enquire"
              onClick={onClose}
              className="px-5 py-2 bg-[#C6A56B] text-[#211D1C] hover:bg-[#d8bb83] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors"
            >
              Enquire For Your Date
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
