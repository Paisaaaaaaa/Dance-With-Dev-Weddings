import React from 'react';
import { STEPS } from '../config/brandConfig';
import { Calendar, Music, Sparkles, Trophy } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const icons = [Calendar, Music, Sparkles, Trophy];

  return (
    <section id="how-it-works" className="py-24 lg:py-32 bg-[#F8F4EC] text-[#211D1C] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[1px] bg-[#651F35]" />
            <span className="text-xs uppercase tracking-[0.25em] text-[#651F35] font-semibold font-sans">
              HOW IT WORKS
            </span>
            <span className="w-6 h-[1px] bg-[#651F35]" />
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#211D1C] font-normal leading-tight mb-4">
            From First Step to the <span className="italic text-[#651F35]">Grand Finale</span>
          </h2>
          <p className="text-sm sm:text-base text-[#211D1C]/75 font-sans font-light max-w-xl mx-auto">
            A relaxed, structured choreography journey designed to remove all wedding stress and maximize your joy.
          </p>
        </div>

        {/* 4 Steps Horizontal / Responsive Timeline */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Subtle Connecting Line for Desktop */}
          <div
            className="hidden lg:block absolute top-12 left-12 right-12 h-[1px] bg-[#C6A56B]/30 -z-0"
            aria-hidden="true"
          />

          {STEPS.map((step, idx) => {
            const Icon = icons[idx];

            return (
              <div
                key={step.stepNumber}
                className="relative z-10 flex flex-col justify-between p-6 sm:p-7 bg-[#FFFFFF] border border-[#C6A56B]/25 rounded-xs shadow-md hover:shadow-xl transition-all duration-300 hover:border-[#651F35]/50 group"
              >
                <div>
                  {/* Step Number & Icon Header */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif text-4xl sm:text-5xl text-[#651F35] font-light group-hover:text-[#C6A56B] transition-colors">
                      {step.stepNumber}
                    </span>
                    <div className="w-10 h-10 rounded-full bg-[#F8F4EC] border border-[#C6A56B]/30 flex items-center justify-center text-[#651F35] group-hover:bg-[#651F35] group-hover:text-[#F8F4EC] transition-all">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="font-serif text-xl sm:text-2xl text-[#211D1C] font-normal mb-2 leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-xs uppercase tracking-wider text-[#651F35] font-sans font-semibold mb-3">
                    {step.tagline}
                  </p>

                  {/* Description */}
                  <p className="text-sm text-[#211D1C]/75 font-sans leading-relaxed font-light mb-6">
                    {step.description}
                  </p>
                </div>

                {/* Timeline Estimate Pill */}
                <div className="pt-4 border-t border-[#C6A56B]/20 text-[11px] text-[#211D1C]/60 font-sans flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C6A56B]" />
                  <span>{step.timelineEstimate}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Step Callout */}
        <div className="mt-16 text-center">
          <a
            href="#enquire"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#651F35] text-[#F8F4EC] hover:bg-[#4A1425] text-xs font-semibold tracking-widest uppercase transition-all rounded-sm shadow-md"
          >
            <span>START STEP 01 — TELL US YOUR PLANS</span>
          </a>
        </div>
      </div>
    </section>
  );
};
